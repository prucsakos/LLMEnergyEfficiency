"""
Calibration subprocess module for isolated calibration runs.
"""
